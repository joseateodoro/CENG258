# Jose Antonio Teodoro n01384776 Section B
## This Application Demonstrates the use of activities and now to launch a browser or 3rd party apps