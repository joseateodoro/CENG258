package jose.teodoro.n01384776;

/*
Jose Teodoro n01384776 Section B
*/

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

public class TeodoroActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teodoro);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), R.string.Activity_Display, Snackbar.LENGTH_LONG);
        snackbar.show();
    }
}